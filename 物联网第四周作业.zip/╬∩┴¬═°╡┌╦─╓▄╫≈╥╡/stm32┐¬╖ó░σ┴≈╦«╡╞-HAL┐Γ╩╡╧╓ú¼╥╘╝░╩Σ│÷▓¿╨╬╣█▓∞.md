# stm32开发板流水灯-HAL库实现，以及输出波形观察

# 1.stm32开发板流水灯-HAL库实现

## 1.1新建项目

点击ACCESS  TO   MCU  SELECTOR新建项目后，输入开发板名字，选择对应开发板，点击Start   Project

![QQ图片20221013172956](C:\Users\19380\Desktop\QQ图片20221013172956.png)



点击Stsyrm Core  处的SYS,在Debug处设置为Serial  Wire

![QQ图片20221013173000](C:\Users\19380\Desktop\QQ图片20221013173000.png)

观察时钟架构，APB2总线的时钟由hse控制，同时在这个界面得把PLLCLK右边选上

![QQ图片20221013173233](C:\Users\19380\Desktop\QQ图片20221013173233.png)

在RCC里的HSE处设为Crystal/Ceramic Resonator	

![QQ图片20221013173246](C:\Users\19380\Desktop\QQ图片20221013173246.png)

在最后侧，找到想要的引脚，点击GPIO_Output

![QQ图片20221013173256](C:\Users\19380\Desktop\QQ图片20221013173256.png)

三个引脚设置完成![QQ图片20221013173259](C:\Users\19380\Desktop\QQ图片20221013173259.png)

点击Project   Mannager,添加文件名，和路径，并且一定要根据情况设置Toolchain处，这里设置为MDK-ARM,并且勾选创建‘.c/.h'files![QQ图片20221013173306](C:\Users\19380\Desktop\QQ图片20221013173306.png)

![QQ图片20221013173302](C:\Users\19380\Desktop\QQ图片20221013173302.png)

点击GENERATE CODE,点击Open   Project

![QQ图片20221013173310](C:\Users\19380\Desktop\QQ图片20221013173310.png)



## 1.2在主函数中添加代码，并测试

![QQ图片20221013174410](C:\Users\19380\Desktop\QQ图片20221013174410.png)

熟悉的烧录步骤

![QQ图片20221013173317](C:\Users\19380\Desktop\QQ图片20221013173317.png)

运行效果

![QQ图片20221013174623](C:\Users\19380\Desktop\QQ图片20221013174623.gif)

# 2.输出波形观察

点击Options  for  Target,在Dubug和Target处进行如下设置

![QQ图片20221013175534](C:\Users\19380\Desktop\QQ图片20221013175534.png)

![QQ图片20221013175537](C:\Users\19380\Desktop\QQ图片20221013175537.png)

注：晶振和板子型号处一定要填对，否则后续会出问题



点击调试按钮

![QQ图片20221013175726](C:\Users\19380\Desktop\QQ图片20221013175726.png)



点击Logic  Analyzer

![QQ图片20221013175731](C:\Users\19380\Desktop\QQ图片20221013175731.png)



将Grid设置为1s,右侧勾选Signal  info ,Cursor,最后点击Setup

![QQ图片20221013175735](C:\Users\19380\Desktop\QQ图片20221013175735.png)



填写PORTA>>5，PORTB>>9，PORTC>>14，这三个实验相关引脚，且都要设置为bit

​                                     ![QQ图片20221013180252](C:\Users\19380\Desktop\QQ图片20221013180252.png)  

点击运行

![QQ图片20221013175744](C:\Users\19380\Desktop\QQ图片20221013175744.png)

实际波形变化时间如下：符合1s的周期

![QQ图片20221013175747](C:\Users\19380\Desktop\QQ图片20221013175747.png)

# 3.总结

学会了更为简单的方法实现Stm32开发板点灯实验，就是利用HAL库，也学会了在实验后如何去观察输出波形，对整个实验有着更为深刻的理解

# 4.参考



[(32条消息) STM32基于HAL库流水灯实验_枫叶的鱼的博客-CSDN博客](https://blog.csdn.net/w798214705/article/details/120954793)

[(32条消息) stm32cubeMX使用HAL库点亮LED流水灯_WOOZI9600L²的博客-CSDN博客](https://blog.csdn.net/weixin_46129506/article/details/120780184)





