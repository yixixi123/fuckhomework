> #         **重庆交通大学信息科学与工程学院**
>
> #             **《嵌入式系统基础A》课程**
>
> #                      作业报告（第x周）

**班 级： <span class="underline"> 物联网工程2002 </span>**

**姓名-学号 ： <span class="underline"> 杨序-632007060529</span>**

**实验项目名称： <span class="underline"> 作业题目 </span>**

**实验项目性质： <span class="underline"> 设计性 </span>**

**实验所属课程： <span class="underline">《嵌入式系统基础》 </span>**

**实验室(中心)： <span class="underline"> 个人pc</span>**

**指 导 教 师 ： <span class="underline">娄路 </span>**

**完成时间： <span class="underline"> 2022</span> 年 <span class="underline"> 10</span> 月 <span class="underline"> 13</span> 日**

------

<div STYLE="page-break-after: always;"></div>

<div STYLE="page-break-after: always;"></div>

**一、实验内容和任务**

### 1、原理学习。学习和理解STM32F103系列芯片的地址映射和寄存器映射原理；了解GPIO端口的初始化设置三步骤（时钟配置、输入输出模式设置、最大速率设置）。 参考qq群中实验指导书相关文件以及网上资料加深理解。（https://blog.csdn.net/geek_monkey/article/details/86291377https://blog.csdn.net/geek_monkey/article/details/86293880） 2、假设你手中已有 STM32最小系统核心板(STM32F103C8T6)+面板板+3只红绿蓝LED，并搭建了电路，分别GPIOA-5、GPIOB-9、GPIOC-14 这3个引脚上控制LED灯（最高时钟2Mhz），轮流闪烁，间隔时长1秒。1）写出程序设计思路，包括GPIOx端口的各寄存器地址和详细参数；2）用C语言 寄存器方式编程实现。参考：https://blog.csdn.net/weixin_47554309/article/details/120810913https://blog.csdn.net/qq_47281915/article/details/120812867  3）安装 stm32CubeMX，用cubemx完成初始化过程，采用HAL库编程实现。 参考： https://blog.csdn.net/weixin_46129506/article/details/120780184 4）在Keil下用软件仿真运行上面代码，并用虚拟逻辑分析仪观察 对应管脚上的输出波形（高低电平转换），看是否是1秒的周期。 

**二、实验要求**

撰写博客，记录实验详细过程。采用提供的实验报告封面，提交报告pdf文件和MD文件； 博客网址、代码git网址到学习通。

三. **实验过程介绍 **

# 1.部分原理阐述

## 1.1地址映射：

为了保证CPU执行指令时可正确访问存储单元,需将用户程序中的逻辑地址转换为运行时由机器直接寻址的物理地址,这一过程称为地址映射

## 1.2寄存器映射：

给已经分配好地址的有特定功能的内存单元取别名的过程就叫寄存器映射

## 1.3时钟配置：

stm32的时钟是由内部或外部振荡器产生的“频率”，而被人们形象的称为“系统时钟”。最大为72MHz换成周期T为：1/72MHz≈13.9ns。因为耗电量，stm32功能强大，能做很多事，但与之同时带来的消耗也越严重，当stm32不引入时钟的话，就像51一样外设全开，相应耗电就很严重了，所以厂家（st公司）为了解决这个问题，引入了“时钟概念”，即使用哪个外设就给哪个外设时钟（频率），不使用的就关掉（不震荡）。此做法大大降低了功耗，续航持久

## 1.4输入输出模式设置：

简单来说输出是CPU计算后进行控制，输入是读取后给CPU进行计算。GPIO的工作模式主要有八种，4种输入方式，4种输出方式。分别为输入浮空，输入上拉，输入下拉，模拟输入；输出方式为开漏输出，开漏复用输出，推挽输出，推挽复用输出。



## 1.5STM32开发板流水灯操作：

其中包含较多寄存器，实现流水灯操作，需要对相应的引脚进行操作

配置时钟使能

配置端口寄存器

配置端口输出寄存器

编写完整程序

烧录程序

运行



# 2.具体实验过程

## 2.1配置时钟使能*   

基地址

![QQ图片20221013122403](QQ图片20221013122403.png)

偏移地址	

![QQ图片20221013122505](QQ图片20221013122505.png)

## 2.2配置端口寄存器*

基地址同上

偏移地址

![QQ图片20221013122356](QQ图片20221013122356.png)



![QQ图片20221013122348](QQ图片20221013122348.png)



## 2.3配置端口输出寄存器*



![QQ图片20221013122353](QQ图片20221013122353.png)



## 2.4 具体寄存器配置



```
#define RCC_AP2ENR	*((unsigned volatile int*)0x40021018)
#define GPIOA_CRL	*((unsigned volatile int*)0x40010800)
#define	GPIOA_ORD	*((unsigned volatile int*)0x4001080C)
#define GPIOB_CRH	*((unsigned volatile int*)0x40010C04)
#define	GPIOB_ORD	*((unsigned volatile int*)0x40010C0C)
#define GPIOC_CRH	*((unsigned volatile int*)0x40011004)
#define	GPIOC_ORD	*((unsigned volatile int*)0x4001100C)
```



## 2.5完整程序*

```
#define RCC_AP2ENR	*((unsigned volatile int*)0x40021018)
#define GPIOA_CRL	*((unsigned volatile int*)0x40010800)
#define	GPIOA_ORD	*((unsigned volatile int*)0x4001080C)
#define GPIOB_CRH	*((unsigned volatile int*)0x40010C04)
#define	GPIOB_ORD	*((unsigned volatile int*)0x40010C0C)
#define GPIOC_CRH	*((unsigned volatile int*)0x40011004)
#define	GPIOC_ORD	*((unsigned volatile int*)0x4001100C)
void  Delay_yx( volatile  unsigned  int  time);
void  Delay_yx( volatile  unsigned  int  time)
{
 volatile    unsigned  int  i=0;
    while(time--){
		i = 2000;
		while(i--){
		}
	}
}
int main()
{
	int j=1;
	RCC_AP2ENR|=1<<2;			
	RCC_AP2ENR|=1<<3;			
	RCC_AP2ENR|=1<<4;			
	
	GPIOA_CRL&=0xFF0FFFFF;		
	GPIOA_CRL|=0x00200000;		
	GPIOA_ORD|=1<<5;			
	
	GPIOB_CRH&=0xFFFFFF0F;		
	GPIOB_CRH|=0x00000020;		
	GPIOB_ORD|=1<<9;			
	
	GPIOC_CRH&=0xF0FFFFFF;		
	GPIOC_CRH|=0x02000000;   	
	GPIOC_ORD|=0x1<<14;			
	while(j)
	{	
		GPIOA_ORD&=0x0<<5;		
		Delay_yx(1000);
		GPIOA_ORD|=0x1<<5;		
		Delay_yx(1000);
		
		GPIOB_ORD&=0x0<<9;		
		Delay_yx(1000);
		GPIOB_ORD|=0x1<<9;		
		Delay_yx(1000);
		
		GPIOC_ORD&=0x0<<14;		
		Delay_yx(1000);
		GPIOC_ORD|=0x1<<14;		
		Delay_yx(1000);
	}
}
```

## 2.6烧录程序

2.6.1勾选Greate HEX Flie，便于生成hex文件

![QQ图片20221013124055](QQ图片20221013124055.png)

2.6.2添加驱动文件，点击Build

![QQ图片20221013124157](QQ图片20221013124157.png)

2.6.3在保存文件路径里找到生成的hex文件，一般是在Objects包里

![QQ图片20221013124409](QQ图片20221013124409.png)

2.6.4 接线

规则：                                               ![QQ图片20221013124855](QQ图片20221013124855.png)

![QQ图片20221013124859](QQ图片20221013124859.png)



实践：

![QQ图片20221013124908](QQ图片20221013124908.jpg)

2.6.5烧录程序

把板子置1

![QQ图片20221013125145](QQ图片20221013125145.jpg)



usb接口连接电脑，利用生成的hex文件，在FlyMcu软件上进行烧录



![QQ图片20221013125418](QQ图片20221013125418.png)



## 2.7运行

烧录程序完毕后，拔掉usb接口，将板子置0后，再将板子通电（usb连接电脑）

![led](led.gif)

# 3.总结

本次实验最基础的部分，就是要了并且掌握何为地址映射，寄存器映射，以及如何根据stm32开发手册去配置时钟使能，配置端口寄存器,配置端口输出寄存器

其次就是实践部分，要掌握如何连接线路，如何烧录程序，特别是连接线路，供电的那条线离led灯远了是无法供电的，而且led灯略长的那一脚要接到正极上

本次用到的所有文件保存到百度网盘：

链接：https://pan.baidu.com/s/1BjaLs3CmnX_YZIW2Qly4KA?pwd=x7zw 
提取码：x7zw

# 4.参考

[(30条消息) STM32F103C8T6实现流水灯_Tarbet的博客-CSDN博客_stm32f103c8t6](https://blog.csdn.net/weixin_47554309/article/details/120810913)

<div STYLE="
            page-break-after: always;"></div>

[(30条消息) STM32寄存器的简介、地址查找，与直接操作寄存器_yummy说电子的博客-CSDN博客_stm32 寄存器地址](https://blog.csdn.net/geek_monkey/article/details/86291377)

[(30条消息) 【嵌入式07】寄存器映射原理详解，GPIO端口的初始化设置步骤_噗噗的罐子的博客-CSDN博客_gpio为什么要初始化](https://blog.csdn.net/qq_46467126/article/details/120737655?spm=1001.2014.3001.5502)

[STM 32 —— Hello World（寄存器方式实现流水灯） - ppqppl - 博客园 (cnblogs.com)](https://www.cnblogs.com/ppqppl/articles/16758829.html)
